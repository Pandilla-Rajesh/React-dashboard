import React from 'react'

const HighOrder = (Original) => {
  return (
    <div>HighOrder</div>
  )
}

export default HighOrder